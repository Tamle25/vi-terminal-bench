# Development benchmark results

**Internal / pending independent review.**

Coverage: 2/2 valid trials. Complete: True.

| Task | EN | VI |
|---|---:|---:|
| b001-vn-invoice | 1 | 1 |

EN macro: 1; VI macro: 1; delta VI-EN: 0 pp.

Conservative token estimate: USD 0.009603000; invoice unavailable; local compute not metered.

Infrastructure failures and missing trials remain explicit. CI unavailable: one family per skill. Smoke and batch coverage are separate.
