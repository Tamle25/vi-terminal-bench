# Development benchmark results

**Internal / pending independent review.**

Coverage: 25/36 valid trials. Complete: False.

| Task | EN | VI |
|---|---:|---:|
| b001-vn-invoice | None | None |
| b002-unicode-files | None | None |
| b003-windows1258 | None | None |
| b004-accent-search | None | None |
| b005-vietnamese-collation | None | 1 |
| b006-vietnamese-csv-export | None | None |

EN macro: None; VI macro: None; delta VI-EN: None pp.

Conservative token estimate: USD 0.078831750; invoice unavailable; local compute not metered.

Infrastructure failures and missing trials remain explicit. CI unavailable: one family per skill. Smoke and batch coverage are separate.
